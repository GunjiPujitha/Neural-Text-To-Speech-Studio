import os
import tempfile


def get_temp_audio_path(extension: str = ".mp3") -> str:
    """Create and return a temporary audio file path."""
    temp_file = tempfile.NamedTemporaryFile(suffix=extension, delete=False)
    temp_file.close()
    return temp_file.name


def remove_temp_file(path: str) -> None:
    """Delete a temporary file if it exists."""
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
