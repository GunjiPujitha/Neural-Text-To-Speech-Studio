import tempfile

from gtts import gTTS


def generate_speech_with_gtts(text: str, lang: str = "en") -> str:
    """Generate speech using the online gTTS engine and return the temp file path."""
    if not text.strip():
        raise ValueError("Text cannot be empty for gTTS generation.")

    output_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    output_file.close()
    tts = gTTS(text=text, lang=lang, slow=False)
    tts.save(output_file.name)
    return output_file.name
