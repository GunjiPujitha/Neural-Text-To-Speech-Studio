from .kokoro_engine import generate_speech_with_kokoro

ENGINE_CHOICES = ["Kokoro (Offline)"]

KOKORO_VOICE_CHOICES = [
    "af_heart",
    "af_bella",
    "af_sarah",
    "am_adam",
    "am_michael",
    "bf_emma",
    "bf_isabella",
    "bm_george",
    "bm_lewis",
]

VOICE_LABELS = {
    "af_heart": "American Female – Heart",
    "af_bella": "American Female – Bella",
    "af_sarah": "American Female – Sarah",
    "am_adam": "American Male – Adam",
    "am_michael": "American Male – Michael",
    "bf_emma": "British Female – Emma",
    "bf_isabella": "British Female – Isabella",
    "bm_george": "British Male – George",
    "bm_lewis": "British Male – Lewis",
}


def get_engine(engine_name: str):
    if engine_name == ENGINE_CHOICES[0]:
        return generate_speech_with_kokoro
    raise ValueError("Unsupported TTS engine selected.")
