import asyncio
import os
import tempfile
import threading
from queue import Queue

from edge_tts import Communicate


async def generate_edge_audio(
    text: str, voice: str, rate: str = "+0%", pitch: str = "+0Hz"
) -> str:
    """Generate natural speech using Edge TTS and return the temporary MP3 path."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Text cannot be empty for Edge TTS generation.")

    output_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    output_file.close()

    try:
        communicate = Communicate(text=text, voice=voice, rate=rate, pitch=pitch)
        await communicate.save(output_file.name)
        return output_file.name
    except Exception:
        try:
            if os.path.exists(output_file.name):
                os.remove(output_file.name)
        except OSError:
            pass
        raise


def _run_coroutine_in_thread(coroutine):
    result_queue: Queue = Queue(maxsize=1)

    def runner() -> None:
        try:
            result = asyncio.run(coroutine)
            result_queue.put((True, result))
        except Exception as exc:  # pragma: no cover
            result_queue.put((False, exc))

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join()

    ok, value = result_queue.get()
    if ok:
        return value
    raise value


def _run_async_task(coroutine):
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coroutine)

    # If a loop is already running (common in app servers), execute in a thread.
    return _run_coroutine_in_thread(coroutine)


def generate_speech_with_edge(
    text: str, voice: str, rate: str = "+0%", pitch: str = "+0Hz"
) -> str:
    """Synchronous wrapper to run Edge TTS from Streamlit."""
    return _run_async_task(generate_edge_audio(text, voice, rate=rate, pitch=pitch))
