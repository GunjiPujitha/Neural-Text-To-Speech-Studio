import re

def _normalize_numbers(text: str) -> str:
    from num2words import num2words

    def replace_number(match: re.Match) -> str:
        return num2words(int(match.group()))

    return re.sub(r"\d+", replace_number, text)


def _enhance_punctuation(text: str) -> str:
    text = re.sub(r"\s*([.,?!;:])\s*", r"\1 ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _split_long_sentences(text: str, max_length: int = 220) -> str:
    if len(text) <= max_length:
        return text

    sentences = []
    start = 0
    while start < len(text):
        end = min(start + max_length, len(text))
        split_pos = text.rfind(".", start, end)
        if split_pos <= start:
            split_pos = text.rfind(",", start, end)
        if split_pos <= start:
            split_pos = end
        else:
            split_pos += 1

        segment = text[start:split_pos].strip()
        if segment:
            sentences.append(segment)
        start = split_pos

    result = " ".join(segment for segment in sentences if segment)
    return result


def preprocess_text(text: str) -> str:
    """Clean and normalize input text while preserving sentence pauses."""
    if not isinstance(text, str):
        return ""

    cleaned = text.strip()
    cleaned = cleaned.replace("Dr.", "Doctor")
    cleaned = cleaned.replace("Mr.", "Mister")
    cleaned = cleaned.replace("\r\n", "\n").replace("\r", "\n")
    cleaned = cleaned.replace("\n", ". ")
    cleaned = _normalize_numbers(cleaned)
    cleaned = re.sub(r"[^A-Za-z0-9\.,\?!;:'\"()\s-]", " ", cleaned)
    cleaned = _enhance_punctuation(cleaned)
    cleaned = _split_long_sentences(cleaned)
    return cleaned.strip()
