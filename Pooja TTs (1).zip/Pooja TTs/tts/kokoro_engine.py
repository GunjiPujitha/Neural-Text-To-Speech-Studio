import io
import numpy as np
import soundfile as sf
from kokoro import KPipeline

_pipelines: dict[str, KPipeline] = {}


def _get_pipeline(lang_code: str) -> KPipeline:
    if lang_code not in _pipelines:
        _pipelines[lang_code] = KPipeline(lang_code=lang_code)
    return _pipelines[lang_code]


def generate_speech_with_kokoro(text: str, voice: str, speed: float = 1.0) -> bytes:
    lang_code = "b" if voice.startswith("b") else "a"
    pipeline = _get_pipeline(lang_code)

    audio_chunks = []
    for _, _, audio in pipeline(text, voice=voice, speed=speed):
        audio_chunks.append(audio)

    combined = np.concatenate(audio_chunks) if len(audio_chunks) > 1 else audio_chunks[0]

    buf = io.BytesIO()
    sf.write(buf, combined, samplerate=24000, format="WAV")
    return buf.getvalue()
